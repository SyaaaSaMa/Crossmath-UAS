import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import os
import subprocess
import sys
import winsound

class MainMenuApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Crossmath Game")

        self.win_width = 1000
        self.win_height = 600
        self.root.geometry(f"{self.win_width}x{self.win_height}")
        self.root.resizable(False, False)

        # --- Set up Musik Latar ---
        self.music_path = None
        self.is_music_playing = False

        try:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            wav_files = [f for f in os.listdir(script_dir) if f.lower().endswith('.wav')]
            
            if wav_files:

                # Jika ada 'music.wav' pakai itu, jika tidak pakai file wav pertama yang ditemukan

                selected_file = 'music.wav' if 'music.wav' in wav_files else wav_files[0]
                music_path = os.path.join(script_dir, selected_file)
                print(f"Memutar musik: {selected_file}")
                winsound.PlaySound(music_path, winsound.SND_FILENAME | winsound.SND_LOOP | winsound.SND_ASYNC)
                self.music_path = os.path.join(script_dir, selected_file)
            else:
                print("Tidak ditemukan musik di folder ini.")
        except Exception as e:
            print(f"Gagal menjalankan musik: {e}")

        # ----------- ganti gambar-----------

        self.current_screen = "main_menu"
        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.main_menu_path = os.path.join(script_dir, 'INTERFACE.png')
        self.pilihan_level_path = os.path.join(script_dir, 'PEMILIHAN LEVEL.png')
        
        try:
            img_main = Image.open(self.main_menu_path).resize((self.win_width, self.win_height), Image.LANCZOS)
            self.bg_image_main_tk = ImageTk.PhotoImage(img_main)

            img_level = Image.open(self.pilihan_level_path).resize((self.win_width, self.win_height), Image.LANCZOS)
            self.bg_image_level_tk = ImageTk.PhotoImage(img_level)

        except FileNotFoundError as e:
            messagebox.showerror("Error", f"File gambar tidak ditemukan: {e}")
            root.destroy()
            return

        self.canvas = tk.Canvas(root, width=self.win_width, height=self.win_height, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.canvas_foto = self.canvas.create_image(0, 0, image=self.bg_image_main_tk, anchor="nw")

        # # --- Tombol Mute ---
        self.mute = tk.Button(self.root, text="Mode ON", font=("Arial", 10, "bold"), 
                                  command=self.toggle_music, bg="#EEEBE3", relief="raised")
        self.mute.place(x=920, y=20)

        if self.music_path:
            self.play_music()

        # Area Tombol Menu Utama
        self.mulai  = (357, 295, 656, 373)
        self.keluar = (357, 391, 656, 463)


        # Area Tombol Pemilihan Level
        self.tombol_level1 = (214, 310,370,369)

        self.tombol_level2 = (392, 310 ,563,369)

        self.tombol_level3 = (581,310, 754, 369)

        self.kembali_btn_area = (431,419,609,465)

        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<Motion>", self.on_mouse_move)

    def on_mouse_move(self, event):
        x, y = event.x, event.y
        is_over_button = False
        if self.current_screen == "main_menu":
            is_over_play = (self.mulai [0] <= x <= self.mulai [2] and
                            self.mulai [1] <= y <= self.mulai [3])
            is_over_quit = (self.keluar[0] <= x <= self.keluar[2] and
                            self.keluar[1] <= y <= self.keluar[3])
            if is_over_play or is_over_quit:
                is_over_button = True

        elif self.current_screen == "pilihan_level":
            bagian_level1 = (self.tombol_level1[0] <= x <= self.tombol_level1[2] and
                            self.tombol_level1[1] <= y <= self.tombol_level1[3])
            bagian_level2 = (self.tombol_level2[0] <= x <= self.tombol_level2[2] and
                            self.tombol_level2[1] <= y <= self.tombol_level2[3])
            bagian_level3 = (self.tombol_level3[0] <= x <= self.tombol_level3[2] and
                            self.tombol_level3[1] <= y <= self.tombol_level3[3])
            bagian_kembali = (self.kembali_btn_area[0] <= x <= self.kembali_btn_area[2] and
                                self.kembali_btn_area[1] <= y <= self.kembali_btn_area[3])
            
            if bagian_level1 or bagian_level2 or bagian_level3 or bagian_kembali:
                is_over_button = True

        if is_over_button:
            self.root.config(cursor="hand2")
        else:
            self.root.config(cursor="")

    def play_music(self):
        if self.music_path:
            try:
                print(f"Memutar musik: {self.music_path}")
                winsound.PlaySound(self.music_path, winsound.SND_FILENAME | winsound.SND_LOOP | winsound.SND_ASYNC)
                self.is_music_playing = True
                self.mute.config(text="🔊 ON", bg="#FFECB3")
            except Exception as e:
                print(f"tidak ada musik tersedoa: {e}")

    def stop_music(self):
        winsound.PlaySound(None, 0)
        self.is_music_playing = False
        self.mute.config(text="OFF", bg="#FFCDD2")

    def toggle_music(self):
        if self.is_music_playing:
            self.stop_music()
        else:
            self.play_music()

    def on_click(self, event):
        x_click, y_click = event.x, event.y
        print(f"Koordinat Klik: x={x_click}, y={y_click}")
        if self.current_screen == "main_menu":
            if (self.mulai [0] <= x_click <= self.mulai [2] and
                self.mulai [1] <= y_click <= self.mulai [3]):
                self.pilihan_level()
            elif (self.keluar[0] <= x_click <= self.keluar[2] and
                  self.keluar[1] <= y_click <= self.keluar[3]):
                self.aksi_quit_game()
        
        elif self.current_screen == "pilihan_level":
            if (self.tombol_level1[0] <= x_click <= self.tombol_level1[2] and
                self.tombol_level1[1] <= y_click <= self.tombol_level1[3]):
                self.mulai_level("LEVEL 1.py")
                
            elif (self.tombol_level2[0] <= x_click <= self.tombol_level2[2] and
                  self.tombol_level2[1] <= y_click <= self.tombol_level2[3]):
                self.mulai_level("LEVEL 2.py")

            elif (self.tombol_level3[0] <= x_click <= self.tombol_level3[2] and
                  self.tombol_level3[1] <= y_click <= self.tombol_level3[3]):
                self.mulai_level("LEVEL 3.py")

            elif (self.kembali_btn_area[0] <= x_click <= self.kembali_btn_area[2] and
                  self.kembali_btn_area[1] <= y_click <= self.kembali_btn_area[3]):
                self.aksi_kembali_ke_menu()

    # --- 6. Fungsi Tombol ---
    def pilihan_level(self):
        print("Masuk ke pemilihan level")
        self.current_screen = "pilihan_level"
        self.canvas.itemconfig(self.canvas_foto, image=self.bg_image_level_tk)

    def aksi_kembali_ke_menu(self):
        print("Kembali")
        self.current_screen = "main_menu"
        self.canvas.itemconfig(self.canvas_foto, image=self.bg_image_main_tk)

    def mulai_level(self, nama_file_level):
        print(f"Mencoba menjalankan level: {nama_file_level}")
        self.root.destroy()

        script_dir = os.path.dirname(os.path.abspath(__file__))
        level_path = os.path.join(script_dir, nama_file_level)
        try:
            subprocess.run([sys.executable, level_path], check=True)
        except FileNotFoundError:
            messagebox.showerror("Error", f"File level '{nama_file_level}' tidak ditemukan!")
        except Exception as e:
            messagebox.showerror("Error", f"Gagal jalankan level:\n{e}")

#  ---------------------------------QUIT GAME----------------------------------
    def aksi_quit_game(self):
        print("Tombol QUIT dipencet")
        if messagebox.askyesno("Keluar", "Apakah anda yakin ingin keluar?"):
            self.root.quit()

if __name__ == "__main__":
    root = tk.Tk()
    app = MainMenuApp(root)
    root.mainloop()