import tkinter as tk
from tkinter import messagebox
import os
import random
import subprocess
import sys

#  ------------------ untuk mengisi soal---------------

def hitung(a, op, b):
    if op == '+': return a + b
    if op == '-': return a - b
    if op == 'x': return a * b
    if op == ':':
        if b == 0: raise ZeroDivisionError
        if a % b != 0: raise ValueError("Hasil pembagian bukan integer")
        return a // b
    raise ValueError(f"Operator tidak dikenal: {op}")
 
class LevelTiga:
    def __init__(self, root):
        self.root = root
        self.root.title("CrossMath - Structured Puzzle")
        self.root.resizable(False, False)
        self.root.geometry("1000x600") 
        self.root.configure(bg="#E3F2FD")

        self.UKURAN_GRID = 11
 
        self.WARNA = {
            'bg': "#E3F2FD",
            'cell_empty': "#FFFFFF",
            'cell_clue': "#81D4FA",
            'cell_result': "#BBDEFB",
            'cell_selected': "#FFF59D",
            'cell_correct': "#A5D6A7",
            'cell_wrong': "#EF9A9A",
            'text': "#01579B",
            'btn_pad': "#E1F5FE"
        }
 
        self.nyawa = 3 # Jumlah kesempatan awal
 
        self.kotak_terpilih = None
        self.kotak_grid = [[None for _ in range(self.UKURAN_GRID)] for _ in range(self.UKURAN_GRID)]
        self.tombol_angka = []
 
        self.buat_header()
 
        
        self.frame_utama = tk.Frame(self.root, bg=self.WARNA['bg'])
        self.frame_utama.pack(fill="both", expand=True, padx=10, pady=10)
 
        
        panel_kanan = tk.Frame(self.frame_utama, bg=self.WARNA['bg'])
        panel_kanan.pack(side="right", fill="y", padx=(20, 0))
        self.buat_numpad(panel_kanan)
        self.buat_tombol(panel_kanan)
 
        
        self.frame_puzzle = tk.Frame(self.frame_utama, bg=self.WARNA['bg'])
        self.frame_puzzle.pack(pady=(10, 0)) # Puzzle di bagian atas area game
 
        self.data_grid = self.buat_soal()
        self.buat_grid() 
 
    def buat_soal(self):
        operator = ['+', '-', 'x', ':']
        
        while True:
            try:
                grid = [[None for _ in range(self.UKURAN_GRID)] for _ in range(self.UKURAN_GRID)]
                persamaan = []
                
                
                
                angka1 = random.randint(1, 20)
                angka2 = random.randint(1, 20)
                op1 = random.choice(['+', '-'])
                hasil1 = hitung(angka1, op1, angka2)
                
                angka3 = random.randint(1, 20)
                op2 = random.choice(['+', '-'])
                hasil2 = hitung(hasil1, op2, angka3)
                
                if not all(-50 < x < 100 for x in [hasil1, hasil2]):
                    continue
 
                
                baris_jembatan = self.UKURAN_GRID // 2
                grid[baris_jembatan][1] = ('', True, angka1)
                grid[baris_jembatan][2] = (op1, False, None)
                grid[baris_jembatan][3] = ('', True, angka2)
                grid[baris_jembatan][4] = ('=', False, None)
                grid[baris_jembatan][5] = (str(hasil1), False, hasil1) # Ini adalah C, titik sambung
                grid[baris_jembatan][6] = (op2, False, None)
                grid[baris_jembatan][7] = ('', True, angka3)
                grid[baris_jembatan][8] = ('=', False, None)
                grid[baris_jembatan][9] = (str(hasil2), False, hasil2)
                
                
                persamaan.append( ((baris_jembatan, 1), (baris_jembatan, 3), (baris_jembatan, 2), (baris_jembatan, 5)) )
                persamaan.append( ((baris_jembatan, 5), (baris_jembatan, 7), (baris_jembatan, 6), (baris_jembatan, 9)) )
                
                
                
                angka4 = random.randint(1, 20)
                op3 = random.choice(operator)
                hasil3 = hitung(angka1, op3, angka4)
                grid[baris_jembatan-2][1] = ('', True, angka4)
                grid[baris_jembatan-1][1] = (op3, False, None)
                grid[baris_jembatan-3][1] = ('=', False, None)
                grid[baris_jembatan-4][1] = (str(hasil3), False, hasil3)
                persamaan.append( ((baris_jembatan, 1), (baris_jembatan-2, 1), (baris_jembatan-1, 1), (baris_jembatan-4, 1)) )
 
                
                angka5 = random.randint(1, 20)
                op4 = random.choice(operator)
                hasil4 = hitung(angka2, op4, angka5)
                grid[baris_jembatan+2][3] = ('', True, angka5)
                grid[baris_jembatan+1][3] = (op4, False, None)
                grid[baris_jembatan+3][3] = ('=', False, None)
                grid[baris_jembatan+4][3] = (str(hasil4), False, hasil4)
                persamaan.append( ((baris_jembatan, 3), (baris_jembatan+2, 3), (baris_jembatan+1, 3), (baris_jembatan+4, 3)) )
 
                
                angka6 = random.randint(1, 20)
                op5 = random.choice(operator)
                hasil5 = hitung(hasil1, op5, angka6)
                grid[baris_jembatan-2][5] = ('', True, angka6)
                grid[baris_jembatan-1][5] = (op5, False, None)
                grid[baris_jembatan-3][5] = ('=', False, None)
                grid[baris_jembatan-4][5] = (str(hasil5), False, hasil5)
                persamaan.append( ((baris_jembatan, 5), (baris_jembatan-2, 5), (baris_jembatan-1, 5), (baris_jembatan-4, 5)) )
 
                
                angka7 = random.randint(1, 20)
                op6 = random.choice(operator)
                hasil6 = hitung(angka3, op6, angka7)
                grid[baris_jembatan+2][7] = ('', True, angka7)
                grid[baris_jembatan+1][7] = (op6, False, None)
                grid[baris_jembatan+3][7] = ('=', False, None)
                grid[baris_jembatan+4][7] = (str(hasil6), False, hasil6)
                persamaan.append( ((baris_jembatan, 7), (baris_jembatan+2, 7), (baris_jembatan+1, 7), (baris_jembatan+4, 7)) )
 
                
                angka8 = random.randint(1, 20)
                op7 = random.choice(operator)
                hasil7 = hitung(hasil2, op7, angka8)
                grid[baris_jembatan-2][9] = ('', True, angka8)
                grid[baris_jembatan-1][9] = (op7, False, None)
                grid[baris_jembatan-3][9] = ('=', False, None)
                grid[baris_jembatan-4][9] = (str(hasil7), False, hasil7)
                persamaan.append( ((baris_jembatan, 9), (baris_jembatan-2, 9), (baris_jembatan-1, 9), (baris_jembatan-4, 9)) )
 
                self.persamaan = persamaan
                return grid
                
            except (ValueError, ZeroDivisionError, TypeError):
                continue
 
    def buat_header(self):
        frame_header = tk.Frame(self.root, bg=self.WARNA['bg'], pady=10)
        frame_header.pack(fill="x")
        
        label_judul = tk.Label(
            frame_header,
            text="LEVEL 3",
            font=("Arial", 20, "bold"),
            bg=self.WARNA['bg'],
            fg=self.WARNA['text']
            )
        label_judul.pack(side="left", padx=20)
        
        self.label_nyawa = tk.Label(
            frame_header,
            text=f" Kesempatan: {self.nyawa}",
            font=("Arial", 16, "bold"),
            bg=self.WARNA['bg'],
            fg="#D32F2F"
            )
        self.label_nyawa.pack(side="right", padx=20)
 
    def buat_grid(self):
        self.kotak_grid = [[None for _ in range(self.UKURAN_GRID)] for _ in range(self.UKURAN_GRID)]
        
        for r, data_baris in enumerate(self.data_grid):
            for c, data_kotak in enumerate(data_baris):
                if data_kotak is None:
                    continue
 
                teks, bisa_diubah, jawaban = data_kotak
 
                if bisa_diubah:
                    bg = self.WARNA['cell_empty']
                    relief = "raised"
                    widget = tk.Button(self.frame_puzzle, text="", font=("Arial", 18, "bold"),
                                       width=3, height=1, bg=bg, relief=relief)
                    widget.config(command=lambda baris=r, kolom=c: self.pilih_kotak(baris, kolom))
                else: 
                    apakah_operator = jawaban is None
                    bg = self.WARNA['cell_clue'] if apakah_operator else self.WARNA['cell_result']
                    relief = "flat"
                    widget = tk.Button(self.frame_puzzle, text=teks, font=("Arial", 18, "bold"),
                                      width=3, height=1, bg=bg, relief=relief, fg=self.WARNA['text'], 
                                      state="disabled", disabledforeground=self.WARNA['text'], borderwidth=0)
                
                widget.grid(row=r, column=c, padx=4, pady=4)
                self.kotak_grid[r][c] = widget
 
    def buat_numpad(self, induk):
        frame_pad = tk.Frame(induk, bg=self.WARNA['bg'])
        frame_pad.pack(side="top", pady=(20, 0))
        
        pad = tk.LabelFrame(frame_pad, text="Pilih Angka", bg=self.WARNA['bg'], font=("Arial", 14, "bold"), padx=10, pady=10)
        pad.pack(expand=True)
 
        angka_angka = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
 
        
        for i in range(5):
            angka = angka_angka[i]
            tombol = tk.Button(pad, text=str(angka), width=4, height=2, font=("Arial", 12, "bold"), command=lambda n=angka: self.masukkan_angka(n), bg=self.WARNA['btn_pad'])
            tombol.grid(row=0, column=i, padx=4, pady=4)
            self.tombol_angka.append(tombol)
        
        
        for i in range(5):
            angka = angka_angka[i+5]
            tombol = tk.Button(pad, text=str(angka), width=4, height=2, font=("Arial", 12, "bold"), command=lambda n=angka: self.masukkan_angka(n), bg=self.WARNA['btn_pad'])
            tombol.grid(row=1, column=i, padx=4, pady=4)
            self.tombol_angka.append(tombol)
 
        
        tombol_hapus = tk.Button(pad, text="Hapus", width=9, height=2, font=("Arial", 12, "bold"), command=self.hapus_input, bg="#FFE0B2")
        tombol_hapus.grid(row=2, column=0, columnspan=2, padx=4, pady=6)
        tombol_tanda = tk.Button(pad, text="+/-", width=9, height=2, font=("Arial", 12, "bold"), command=self.ganti_tanda, bg="#CFD8DC")
        tombol_tanda.grid(row=2, column=2, columnspan=2, padx=4, pady=6)
 
    def buat_tombol(self, induk):
        frame_bawah = tk.Frame(induk, bg=self.WARNA['bg'])
        frame_bawah.pack(side="top", pady=(20, 0))
 
        tk.Button(frame_bawah, text=" Ganti Soal", width=10, font=("Arial", 12, "bold"),
                  command=self.soal_baru, bg="#FFECB3").pack(pady=10)
        tk.Button(frame_bawah, text="⬅ Kembali", width=10, font=("Arial", 12, "bold"),
                  command=self.kembali, bg="#FFCDD2").pack(pady=10)
        tk.Button(frame_bawah, text="✔️ Cek Jawaban", width=12, font=("Arial", 12, "bold"),
                  command=self.cek_jawaban, bg="#C8E6C9").pack(pady=10)
        
    def soal_baru(self):
        
        for widget in self.frame_puzzle.winfo_children():
            widget.destroy()

        
        self.nyawa = 3
        self.label_nyawa.config(text=f"Kesempatan: {self.nyawa}")
        self.kotak_terpilih = None
        
        
        self.data_grid = self.buat_soal()
        self.buat_grid()
    
    def kembali(self):
        self.root.destroy()
        script_dir = os.path.dirname(os.path.abspath(__file__))
        interface_path = os.path.join(script_dir, "INTERFACE.py")
        subprocess.run([sys.executable, interface_path])
 
    def pilih_kotak(self, baris, kolom):
        if self.kotak_terpilih:
            baris_lama, kolom_lama = self.kotak_terpilih
            
            widget_lama = self.kotak_grid[baris_lama][kolom_lama]
            if widget_lama and widget_lama['state'] != 'disabled':
                 widget_lama.config(bg=self.WARNA['cell_empty'])
 
        self.kotak_terpilih = (baris, kolom)
        self.kotak_grid[baris][kolom].config(bg=self.WARNA['cell_selected'])
 
    def masukkan_angka(self, angka):
        if not self.kotak_terpilih or self.nyawa <= 0: 
            return
 
        baris, kolom = self.kotak_terpilih
        tombol = self.kotak_grid[baris][kolom]
        if tombol['state'] != 'disabled':
            teks_sekarang = tombol['text']
            
            
            if not teks_sekarang or (teks_sekarang == '0' and angka != 0):
                teks_baru = str(angka)
            
            elif len(teks_sekarang.replace('-', '')) < 3:
                teks_baru = teks_sekarang + str(angka)
            else: 
                teks_baru = teks_sekarang
 
            tombol.config(text=teks_baru, bg=self.WARNA['cell_empty'])
 
    def hapus_input(self):
        if self.kotak_terpilih:
            r, c = self.kotak_terpilih
            tombol = self.kotak_grid[r][c]
            if tombol and tombol['state'] != 'disabled':
                tombol.config(text="")
 
    def ganti_tanda(self):
        if self.kotak_terpilih:
            r, c = self.kotak_terpilih
            tombol = self.kotak_grid[r][c]
            if tombol and tombol['state'] != 'disabled' and tombol['text']:
                try:
                    angka_sekarang = int(tombol['text'])
                    tombol.config(text=str(angka_sekarang * -1))
                except ValueError:
                    pass
 
    def kalah(self):
        messagebox.showerror("Game Over", "Kesempatanmu sudah habis! Coba lagi di soal berikutnya.")
        
        for r_idx, baris in enumerate(self.kotak_grid):
            for c_idx, widget in enumerate(baris):
                if widget and self.data_grid[r_idx][c_idx] and self.data_grid[r_idx][c_idx][1]:
                    if widget['state'] != 'disabled':
                        widget.config(state='disabled', bg=self.WARNA['cell_empty'])
        
        for tombol in self.tombol_angka:
            tombol.config(state='disabled')
            
    def cek_menang(self):
        sudah_menang = True
        for r, data_baris in enumerate(self.data_grid):
            for c, data_kotak in enumerate(data_baris):
                if data_kotak and data_kotak[1]: # Jika kotak bisa diisi
                    if self.kotak_grid[r][c]['state'] != 'disabled':
                        sudah_menang = False
                        break
            if not sudah_menang: break
        
        if sudah_menang:
            self.root.destroy()
            script_dir = os.path.dirname(os.path.abspath(__file__))
            layar_menang_path = os.path.join(script_dir, "WINSCREEN.py")
            subprocess.run([sys.executable, layar_menang_path])
 
    def cek_jawaban(self):
        if self.nyawa <= 0: return
 
        semua_persamaan_benar = True
        
        for i, peta_persamaan in enumerate(self.persamaan):
            (r1, c1), (r2, c2), (ro, co), (rr, cr) = peta_persamaan
            
            widget_val1 = self.kotak_grid[r1][c1]
            widget_val2 = self.kotak_grid[r2][c2]
            
            teks_val1 = widget_val1['text'] if widget_val1 else self.data_grid[r1][c1][0]
            teks_val2 = widget_val2['text'] if widget_val2 else self.data_grid[r2][c2][0]
            
            teks_op = self.data_grid[ro][co][0] if self.data_grid[ro][co] else ''
            teks_hasil = self.data_grid[rr][cr][0] if self.data_grid[rr][cr] else ''
 
            if not teks_val1 or not teks_val2 or not teks_op or not teks_hasil:
                semua_persamaan_benar = False
                continue
            try:
                v1 = int(teks_val1)
                v2 = int(teks_val2)
                target_hasil = int(teks_hasil)
                jawaban_benar = False
                pasangan_input = [(v1, v2)]
                if teks_op in ['+', 'x']:
                    pasangan_input.append((v2, v1))
                for pasangan in pasangan_input:
                    try:
                        if hitung(pasangan[0], teks_op, pasangan[1]) == target_hasil:
                            jawaban_benar = True
                            break
                    except (ValueError, ZeroDivisionError):
                        continue
                if not jawaban_benar:
                    semua_persamaan_benar = False
                    if widget_val1 and widget_val1['state'] != 'disabled': widget_val1.config(bg=self.WARNA['cell_wrong'])
                    if widget_val2 and widget_val2['state'] != 'disabled': widget_val2.config(bg=self.WARNA['cell_wrong'])
                else:
                    if widget_val1 and widget_val1['state'] != 'disabled': widget_val1.config(bg=self.WARNA['cell_correct'], state='disabled', relief='flat')
                    if widget_val2 and widget_val2['state'] != 'disabled': widget_val2.config(bg=self.WARNA['cell_correct'], state='disabled', relief='flat')
            except (ValueError, ZeroDivisionError):
                semua_persamaan_benar = False
        if not semua_persamaan_benar:
            self.nyawa -= 1
            self.label_nyawa.config(text=f" Kesempatan: {self.nyawa}")
            if self.nyawa <= 0:
                self.kalah()
            else:
                messagebox.showwarning("Jawaban Salah", "Ada jawaban yang salah. Kesempatan berkurang!")
        else:
            self.cek_menang()
if __name__ == "__main__":
    root = tk.Tk()
    LevelTiga(root)
    root.mainloop()