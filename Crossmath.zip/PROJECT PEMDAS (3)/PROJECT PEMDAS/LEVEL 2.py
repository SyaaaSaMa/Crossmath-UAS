import tkinter as tk
from tkinter import messagebox
import random
import subprocess
import sys


class CrossMathLevel2:
    # Mengatur window utama, warna, dan menyiapkan game
    def __init__(self, root):
        self.root = root
        self.root.title("CrossMath - Level 2 (Medium)")
        self.root.geometry("1000x600")
        self.root.configure(bg="#E3F2FD")
        self.root.resizable(False, False)

        self.COLORS = {
            'bg': "#E3F2FD",
            'cell_empty': "#FFFFFF",
            'cell_clue': "#81D4FA",
            'cell_result': "#4FC3F7",
            'cell_selected': "#FFF59D",
            'cell_correct': "#A5D6A7",
            'cell_wrong': "#EF9A9A",
            'text': "#01579B",
            'btn_pad': "#E1F5FE"
        }

        self.grid_data = self.generate_random_puzzle()
        self.cells_widgets = {}
        self.selected_cell = None
        self.mistakes = 0

        self.create_header()

        main = tk.Frame(root, bg=self.COLORS['bg'])
        main.pack(expand=True)

        grid = tk.Frame(main, bg=self.COLORS['bg'])
        grid.pack(side="left", padx=10)

        panel = tk.Frame(main, bg=self.COLORS['bg'])
        panel.pack(side="right", fill="y", padx=(20, 0))

        self.create_grid_ui(grid)
        self.create_numpad(panel)
        self.create_side_buttons(panel)

    # Menerapkan operasi matematika
    def _apply_op(self, a, op, b):
        if op == '+':
            return a + b
        if op == '-':
            return a - b
        if op == 'x':
            return a * b
        if op == '÷':
            return a // b if b != 0 and a % b == 0 else None
        return None

    # Menentukan warna sel
    def get_cell_color(self, text):
        return self.COLORS['cell_clue'] if text in ['=', '+', '-', 'x', '÷'] else self.COLORS['cell_result']

    # Membuat soal acak (AMAN, tidak error)
    def generate_random_puzzle(self):
        while True:
            try:
                b, r1 = random.randint(2, 5), random.randint(2, 5)
                a = b * r1

                c, d = random.randint(2, 7), random.randint(2, 7)
                r2 = c * d

                op3, op4 = random.choice(['+', '-']), random.choice(['+', '-'])
                r3 = self._apply_op(a, op3, c)
                r4 = self._apply_op(b, op4, d)

                if not all(0 < x < 50 for x in [a, r2, r3, r4]):
                    continue

                return [
                    [('', True, a), ('÷', False, '÷'), ('', True, b), ('=', False, '='), (str(r1), False, r1)],
                    [(op3, False, op3), (None, False, None), (op4, False, op4), (None, False, None), (None, False, None)],
                    [('', True, c), ('x', False, 'x'), ('', True, d), ('=', False, '='), (str(r2), False, r2)],
                    [('=', False, '='), (None, False, None), ('=', False, '='), (None, False, None), (None, False, None)],
                    [(str(r3), False, r3), (None, False, None), (str(r4), False, r4), (None, False, None), (None, False, None)],
                ]
            except:
                continue

    # Header level dan kesalahan
    def create_header(self):
        frame = tk.Frame(self.root, bg=self.COLORS['bg'], pady=20)
        frame.pack(fill="x")

        tk.Label(frame, text="LEVEL 2", font=("Arial", 20, "bold"),
                 bg=self.COLORS['bg'], fg="#01579B").pack(side="left", padx=20)

        self.mistake_label = tk.Label(frame, text="Salah: 0/3",
                                      font=("Arial", 12, "bold"),
                                      bg=self.COLORS['bg'], fg="#C62828")
        self.mistake_label.pack(side="right", padx=20)

    # Grid 5x5
    def create_grid_ui(self, parent):
        for r in range(5):
            for c in range(5):
                text, editable, _ = self.grid_data[r][c]

                if text is None:
                    tk.Label(parent, bg=self.COLORS['bg'], width=5).grid(row=r, column=c)
                    continue

                btn = tk.Button(
                    parent,
                    text=text,
                    width=4,
                    height=2,
                    font=("Arial", 16, "bold"),
                    bg=self.COLORS['cell_empty'] if editable else self.get_cell_color(text),
                    relief="sunken" if editable else "flat",
                    state="normal" if editable else "disabled",
                    fg=self.COLORS['text']
                )
                btn.grid(row=r, column=c, padx=4, pady=4)

                if editable:
                    btn.config(command=lambda r=r, c=c: self.select_cell(r, c))

                self.cells_widgets[(r, c)] = btn

    # Keypad angka
    def create_numpad(self, parent):
        frame = tk.Frame(parent, bg=self.COLORS['bg'], pady=20)
        frame.pack()

        keys = [[1, 2, 3], [4, 5, 6], [7, 8, 9], ['Hapus', 0, '+/-']]

        for r, row in enumerate(keys):
            for c, key in enumerate(row):
                if isinstance(key, int):
                    cmd = lambda n=key: self.input_number(n)
                elif key == 'Hapus':
                    cmd = self.clear_selected
                else:
                    cmd = self.toggle_sign

                tk.Button(frame, text=str(key), width=5, height=2,
                          font=("Arial", 12, "bold"),
                          bg=self.COLORS['btn_pad'],
                          command=cmd).grid(row=r, column=c, padx=6, pady=6)

    # Tombol samping
    def create_side_buttons(self, parent):
        frame = tk.Frame(parent, bg=self.COLORS['bg'])
        frame.pack(pady=20)

        tk.Button(frame, text="Ganti Soal", width=14,
                  bg="#FFECB3", command=self.new_puzzle).pack(pady=10)

        tk.Button(frame, text="Kembali", width=14,
                  bg="#FFCDD2", command=self.kembalik).pack()

        tk.Button(frame, text="Cek Semua Jawaban", width=18,
                  bg="#C8E6C9", command=self.check_all_answers).pack(pady=10)

    # Pilih sel
    def select_cell(self, r, c):
        if self.selected_cell:
            self.cells_widgets[self.selected_cell].config(bg=self.COLORS['cell_empty'])
        self.selected_cell = (r, c)
        self.cells_widgets[(r, c)].config(bg=self.COLORS['cell_selected'])

    # Input angka
    def input_number(self, n):
        if self.selected_cell:
            btn = self.cells_widgets[self.selected_cell]
            btn.config(text=btn['text'] + str(n) if btn['text'] else str(n))

    # Hapus isi sel
    def clear_selected(self):
        if self.selected_cell:
            self.cells_widgets[self.selected_cell].config(text="")

    # Ubah tanda
    def toggle_sign(self):
        if self.selected_cell:
            try:
                btn = self.cells_widgets[self.selected_cell]
                btn.config(text=str(-int(btn['text'])))
            except:
                pass

    # Ganti soal
    def new_puzzle(self):
        self.grid_data = self.generate_random_puzzle()
        self.mistakes = 0
        self.mistake_label.config(text="Salah: 0/3")

        for (r, c), btn in self.cells_widgets.items():
            text, editable, _ = self.grid_data[r][c]
            btn.config(
                text="" if editable else text,
                bg=self.COLORS['cell_empty'] if editable else self.get_cell_color(text),
                state="normal" if editable else "disabled",
                relief="sunken" if editable else "flat"
            )

    # Kembali ke menu
    def kembalik(self):
        self.root.destroy()
        subprocess.run([sys.executable, "INTERFACE.py"])

    # Cek jawaban
    def check_all_answers(self):
        try:
            a = int(self.cells_widgets[(0, 0)]['text'])
            b = int(self.cells_widgets[(0, 2)]['text'])
            c = int(self.cells_widgets[(2, 0)]['text'])
            d = int(self.cells_widgets[(2, 2)]['text'])
        except:
            messagebox.showwarning("Peringatan", "Isi semua kotak!")
            return

        r1 = self.grid_data[0][4][2]
        r2 = self.grid_data[2][4][2]
        r3 = self.grid_data[4][0][2]
        r4 = self.grid_data[4][2][2]

        if (
            self._apply_op(a, '÷', b) == r1 and
            c * d == r2 and
            self._apply_op(a, self.grid_data[1][0][2], c) == r3 and
            self._apply_op(b, self.grid_data[1][2][2], d) == r4
        ):
            self.root.destroy()
            subprocess.run([sys.executable, "WINSCREEN.py"])
        else:
            self.mistakes += 1
            self.mistake_label.config(text=f"Salah: {self.mistakes}/3")
            messagebox.showerror("Salah", "Masih ada jawaban yang salah!")


if __name__ == "__main__":
    root = tk.Tk()
    CrossMathLevel2(root)
    root.mainloop()