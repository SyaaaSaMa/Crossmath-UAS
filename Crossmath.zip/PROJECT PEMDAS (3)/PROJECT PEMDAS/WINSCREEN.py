import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import os
import subprocess
import sys

class WinScreenApp:
    # mengatur window utama, backgound, area klik tombol menu, menghubungkan event mouse
    def __init__(self, root):
        self.root = root
        self.root.title("You Win!")
        self.win_width = 1000
        self.win_height = 600
        self.root.geometry(f"{self.win_width}x{self.win_height}")
        self.root.resizable(False, False)

        # Mengambil lokasi folder file Python ini
        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.bg_path = os.path.join(script_dir, 'DONE.png')

        # Memuat gambar background
        try:
            img = Image.open(self.bg_path).resize(
                (self.win_width, self.win_height),
                Image.LANCZOS
            )
            self.bg_image_tk = ImageTk.PhotoImage(img)
        except FileNotFoundError:
            # Jika gambar tidak ditemukan
            messagebox.showerror("Error", "File DONE.png tidak ditemukan!")
            self.root.destroy()
            return

        # Membuat canvas untuk menampilkan gambar
        self.canvas = tk.Canvas(
            root,
            width=self.win_width,
            height=self.win_height,
            highlightthickness=0
        )
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_image(0, 0, image=self.bg_image_tk, anchor="nw")

        # Area koordinat tombol "Menu Utama" pada gambar
        self.menu_btn_area = (388, 375, 650, 437)

        #mouse klik dan gerak mouse
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<Motion>", self.on_mouse_move)

    #mengubah kursor menjadi tangan jika berada di area tombol
    def on_mouse_move(self, event):
        x, y = event.x, event.y
        is_over_menu = (
            self.menu_btn_area[0] <= x <= self.menu_btn_area[2] and
            self.menu_btn_area[1] <= y <= self.menu_btn_area[3]
        )

        if is_over_menu:
            self.root.config(cursor="hand2")
        else:
            self.root.config(cursor="")

    #mengecek saat mouse di klik apakah berada di area tombol menu
    def on_click(self, event):
        x, y = event.x, event.y
        print(f"Koordinat Klik: x={x}, y={y}")

        if (
            self.menu_btn_area[0] <= x <= self.menu_btn_area[2] and
            self.menu_btn_area[1] <= y <= self.menu_btn_area[3]
        ):
            self.aksi_menu_utama()

    #kembali ke menu utama(menutup window win screen dan menjalankan INTERFACE.py)
    def aksi_menu_utama(self):
        print("Ke Menu Utama...")
        self.root.destroy()
        script_dir = os.path.dirname(os.path.abspath(__file__))
        interface_path = os.path.join(script_dir, 'INTERFACE.py')
        subprocess.run([sys.executable, interface_path])

# Program utama
if __name__ == "__main__":
    root = tk.Tk()
    app = WinScreenApp(root)
    root.mainloop()