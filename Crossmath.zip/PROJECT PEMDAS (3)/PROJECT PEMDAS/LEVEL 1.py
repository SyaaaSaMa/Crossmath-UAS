import tkinter as tk
from tkinter import messagebox
import random
import os
import subprocess
import sys

class CrossMathGame:
    def __init__(self, root):
        self.root = root
        self.root.title("CrossMath LEVEL 1")
        self.root.geometry("1000x600")
        self.root.resizable(False, False)
        self.root.configure(bg="#E3F2FD")

        self.COLORS = {
            'bg': "#E3F2FD",
            'cell_empty': "#FFFFFF",
            'cell_clue': "#BBDEFB",
            'cell_selected': "#FFF59D",
            'cell_correct': "#A5D6A7",
            'cell_wrong': "#EF9A9A",
            'text': "#1565C0",
            'btn_pad': "#E1F5FE"
        }

        self.grid_data = self.generate_random_puzzle()

        self.selected_cell = None
        self.mistakes = 0
        self.cells_widgets = {}

        self.create_header()

        main_frame = tk.Frame(self.root, bg=self.COLORS['bg'])
        main_frame.pack(expand=True)

        grid_frame = tk.Frame(main_frame, bg=self.COLORS['bg'])
        grid_frame.pack(side="left", padx=10)

        right_panel = tk.Frame(main_frame, bg=self.COLORS['bg'])
        right_panel.pack(side="right", fill="y", padx=(20, 0))

        self.create_grid_ui(grid_frame)
        self.create_numpad(right_panel)
        self.bantuan(right_panel)
        
    def _apply_op(self, a, op, b):
        """Fungsi helper untuk menerapkan operasi."""
        if op == '+':
            return a + b
        if op == '-':
            return a - b
        return None

    def generate_random_puzzle(self):
        while True:
            a, b, c, d = [random.randint(1, 9) for _ in range(4)]
            
            operators = ['+', '-']
            tabel1, tabel2, op_v1, op_v2 = [random.choice(operators) for _ in range(4)]
            
            h1 = self._apply_op(a, tabel1, b)
            h2 = self._apply_op(c, tabel2, d)
            v1 = self._apply_op(a, op_v1, c)
            v2 = self._apply_op(b, op_v2, d)
            
            return [
                [('', True, a), (tabel1, False, tabel1), ('', True, b), ('=', False, '='), (str(h1), False, h1)],
                [(op_v1, False, op_v1), (None, False, None), (op_v2, False, op_v2), (None, False, None), (None, False, None)],
                [('', True, c), (tabel2, False, tabel2), ('', True, d), ('=', False, '='), (str(h2), False, h2)],
                [('=', False, '='), (None, False, None), ('=', False, '='), (None, False, None), (None, False, None)],
                [(str(v1), False, v1), (None, False, None), (str(v2), False, v2), (None, False, None), (None, False, None)],
            ]

    def create_header(self):
        header_frame = tk.Frame(self.root, bg=self.COLORS['bg'], pady=20)
        header_frame.pack(fill="x")

        self.mistake_label = tk.Label(header_frame, text=f"Kesalahan: {self.mistakes}/3",
                                      font=("Arial", 12, "bold"),
                                      bg=self.COLORS['bg'], fg="#C62828")
        self.mistake_label.pack(side="right", padx=20)

        title = tk.Label(header_frame, text="LEVEL 1", font=("Arial", 20, "bold"),
                         bg=self.COLORS['bg'], fg="#0D47A1")
        title.pack(side="left", padx=20)

    def create_grid_ui(self, parent_frame):

        rows = len(self.grid_data)
        cols = len(self.grid_data[0])

        for r in range(rows):
            for c in range(cols):
                cell_info = self.grid_data[r][c]

                if cell_info is None or cell_info[0] is None:
                    continue

                display_text, is_editable, answer = cell_info

                if is_editable:
                    bg_color = self.COLORS['cell_empty']
                    relief_style = "sunken"
                    state_val = "normal"
                else:
                    bg_color = self.COLORS['cell_clue']
                    relief_style = "flat"
                    state_val = "disabled"

                btn = tk.Button(
                    parent_frame, text=display_text,
                    font=("Arial", 16, "bold"),
                    width=4, height=2,
                    bd=2, relief=relief_style,
                    bg=bg_color, fg=self.COLORS['text'],
                    state=state_val
                )

                btn.grid(row=r, column=c, padx=4, pady=4)

                if is_editable:
                    btn.config(command=lambda row=r, col=c: self.select_cell(row, col))

                self.cells_widgets[(r, c)] = btn

    def create_numpad(self, parent_frame):
        pad_frame = tk.Frame(parent_frame, bg=self.COLORS['bg'], pady=20)
        pad_frame.pack(side="top", fill="x")

        inner = tk.Frame(pad_frame, bg=self.COLORS['bg'])
        inner.pack()

        tombol = [
            [1, 2, 3],
            [4, 5, 6],
            [7, 8, 9],
            ['Hapus', 0, '+/-']
        ]

        for r, row_keys in enumerate(tombol):
            for c, key in enumerate(row_keys):
                if isinstance(key, int):
                    tk.Button(inner, text=str(key), font=("Arial", 14, "bold"), width=5, height=2,
                              bg=self.COLORS['btn_pad'], fg="#0277BD", relief="raised", bd=3,
                              command=lambda n=key: self.input_number(n)).grid(row=r, column=c, padx=6, pady=6)
                elif key == 'Hapus':
                    tk.Button(inner, text="Hapus", font=("Arial", 12, "bold"), width=5, height=2,
                              bg="#FFE0B2", command=self.clear_selected).grid(row=r, column=c, padx=6, pady=6)
                elif key == '+/-':
                    tk.Button(inner, text="+/-", font=("Arial", 12, "bold"), width=5, height=2,
                              bg="#CFD8DC", command=self.toggle_sign).grid(row=r, column=c, padx=6, pady=6)

    def bantuan(self, parent_frame):
        sampingan = tk.Frame(parent_frame, bg=self.COLORS['bg'])
        sampingan.pack(pady=20)

        tk.Button(sampingan, text="Ganti Soal",
                  width=12, font=("Arial", 11, "bold"),
                  bg="#FFECB3",
                  command=self.soal_baru).pack(pady=10)

        tk.Button(sampingan, text="Kembali", 
                  width=12, font=("Arial", 11, "bold"),
                  bg="#FFCDD2", 
                  command=self.kembalik).pack()

        tk.Button(sampingan, text="Cek Semua Jawaban",
                  font=("Arial", 11, "bold"),
                  bg="#C8E6C9",
                  command=self.check_all_answers).pack(pady=10)

    def kembalik(self):
        self.root.destroy()
        script_dir = os.path.dirname(os.path.abspath(__file__))
        main_menu_path = os.path.join(script_dir, "INTERFACE.py")
        try:
            subprocess.run([sys.executable, main_menu_path], check=True)
        except FileNotFoundError:
            messagebox.showerror("Error", f"File menu utama '{os.path.basename(main_menu_path)}' tidak ditemukan!")

    def soal_baru(self):
        self.grid_data = self.generate_random_puzzle()

        self.mistakes = 0
        self.mistake_label.config(text=f"Kesalahan: {self.mistakes}/3")
        self.selected_cell = None

        for (r, c), widget in self.cells_widgets.items():
            display_text, is_editable, answer = self.grid_data[r][c]

            if is_editable:
                widget.config(text="", bg=self.COLORS['cell_empty'], state="normal", relief="sunken")
            else:
                widget.config(text=display_text, bg=self.COLORS['cell_clue'], state="disabled", relief="flat")

        if self.selected_cell:
            self.cells_widgets[self.selected_cell].config(bg=self.COLORS['cell_empty'])

    def select_cell(self, row, col):
        if self.selected_cell:
            r, c = self.selected_cell
            prev_widget = self.cells_widgets.get((r, c))
            if prev_widget and prev_widget['state'] != 'disabled':
                if prev_widget.cget('bg') != self.COLORS['cell_wrong']:
                    prev_widget.config(bg=self.COLORS['cell_empty'])

        self.selected_cell = (row, col)
        self.cells_widgets[(row,col)].config(bg=self.COLORS['cell_selected'])

    def input_number(self, number):
        if not self.selected_cell:
            return

        row, col = self.selected_cell
        widget = self.cells_widgets[(row, col)]
        if widget['state'] == 'disabled':
            return

        current_text = widget['text']
        
        if not current_text or (current_text == '0' and number != 0):
            new_text = str(number)
        elif len(current_text.replace('-', '')) < 2:
            new_text = current_text + str(number)
        else:
            new_text = current_text

        widget.config(text=new_text, bg=self.COLORS['cell_selected'])

    def clear_selected(self):
        """Menghapus angka dari sel yang dipilih."""
        if self.selected_cell:
            r, c = self.selected_cell
            widget = self.cells_widgets.get((r, c))
            if widget and widget['state'] != 'disabled':
                widget.config(text="")

    def toggle_sign(self):
        """Mengubah tanda (positif/negatif) dari angka di sel yang dipilih."""
        if self.selected_cell:
            r, c = self.selected_cell
            widget = self.cells_widgets.get((r, c))
            if widget and widget['state'] != 'disabled' and widget['text']:
                try:
                    current_num = int(widget['text'])
                    widget.config(text=str(current_num * -1))
                except ValueError:
                    pass
    def check_all_answers(self):
        if self.mistakes >= 3:
            return

        try:
            a = int(self.cells_widgets[(0, 0)]['text'])
            b = int(self.cells_widgets[(0, 2)]['text'])
            c = int(self.cells_widgets[(2, 0)]['text'])
            d = int(self.cells_widgets[(2, 2)]['text'])
        except (ValueError, KeyError):
            messagebox.showwarning("Peringatan", "Harap isi semua kotak sebelum memeriksa jawaban!")
            return

        tabel1 = self.grid_data[0][1][2]
        h1 = self.grid_data[0][4][2]
        
        tabel2 = self.grid_data[2][1][2]
        h2 = self.grid_data[2][4][2]

        op_v1 = self.grid_data[1][0][2]
        v1 = self.grid_data[4][0][2]

        op_v2 = self.grid_data[1][2][2]
        v2 = self.grid_data[4][2][2]

        eq1_correct = self._apply_op(a, tabel1, b) == h1
        eq2_correct = self._apply_op(c, tabel2, d) == h2
        eq3_correct = self._apply_op(a, op_v1, c) == v1
        eq4_correct = self._apply_op(b, op_v2, d) == v2

        if eq1_correct and eq2_correct and eq3_correct and eq4_correct:
            for r, c in [(0, 0), (0, 2), (2, 0), (2, 2)]:
                self.cells_widgets[(r, c)].config(bg=self.COLORS['cell_correct'], state='disabled', relief='flat')
            self.root.destroy()
            script_dir = os.path.dirname(os.path.abspath(__file__))
            main_menu_path = os.path.join(script_dir, "WINSCREEN.py")
            subprocess.run([sys.executable, main_menu_path])
        else:
            self.mistakes += 1
            self.mistake_label.config(text=f"Kesalahan: {self.mistakes}/3")
            
            if not eq1_correct:
                self.cells_widgets[(0, 0)].config(bg=self.COLORS['cell_wrong'])
                self.cells_widgets[(0, 2)].config(bg=self.COLORS['cell_wrong'])
            if not eq2_correct:
                self.cells_widgets[(2, 0)].config(bg=self.COLORS['cell_wrong'])
                self.cells_widgets[(2, 2)].config(bg=self.COLORS['cell_wrong'])
            if not eq3_correct:
                self.cells_widgets[(0, 0)].config(bg=self.COLORS['cell_wrong'])
                self.cells_widgets[(2, 0)].config(bg=self.COLORS['cell_wrong'])
            if not eq4_correct:
                self.cells_widgets[(0, 2)].config(bg=self.COLORS['cell_wrong'])
                self.cells_widgets[(2, 2)].config(bg=self.COLORS['cell_wrong'])

            if self.mistakes >= 3:
                messagebox.showerror("Game Over", "Yahhh, kamu kalah! Soal ganti")
                self.soal_baru()
            else:
                messagebox.showerror("Salah", "Masih ada yang salah. Coba perbaiki")

if __name__ == "__main__":
    root = tk.Tk()
    CrossMathGame(root)
    root.mainloop()